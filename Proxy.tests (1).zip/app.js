const tg = window.Telegram.WebApp;

tg.ready();
tg.expand();

function openNews() {
    tg.showAlert("📰 Yangiliklar bo‘limi tez orada ishlaydi.");
}

function openTickets() {
    tg.showAlert("🎫 Chipta bo‘limi tez orada ishlaydi.");
}

function openTests() {
    tg.showAlert("📝 Testlar bo‘limi tez orada ishlaydi.");
}